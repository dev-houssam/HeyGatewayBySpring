package com.api.heyGateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;

import java.util.LinkedList;

class BeansEntity {
	T entity = null;
	LinkedList list1 = new LinkedList<RouteLocatorBuilder>();
	public BeansEntity(RouteLocatorBuilder b){
		list1.add(b);
	}

	public void apply(){
		list1.forEach();
	}
}

@SpringBootApplication
public class GatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(GatewayApplication.class, args);
	}

	RouteLocatorBuilder builder = null;

	@Bean
	public void initiator(RouteLocatorBuilder builder){
		this.builder = builder;
	}

	public void addGatewayEntity(BeanEntity b){
		 this.builder =
	}

	@Bean
	public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {
		return builder.routes()
				.route(r -> r.path("/movies/**")
						.filters(f -> f
							.prefixPath("/")
							.addResponseHeader("X-Powered-By","Houssam's Movies  Gateway Service")
						)
						.uri("http://localhost:9001")
				)
				.route(r -> r.path("/comments/**")
						.filters(f -> f
								.prefixPath("/api")
								.addResponseHeader("X-Powered-By","DanSON Gateway Service")
						)
						.uri("http://localhost:8082")
				)
				.build();
	}

	@Bean
	public RouteLocator mainBean(){
		return this.
	}

	@Bean
	public RouteLocator customBeanRouteLocator(RouteLocatorBuilder builder) {
		return builder.routes()
				.route(r -> r.path("/google/**")
						.filters(f -> f
								.prefixPath("/")
								.addResponseHeader("X-Powered-By","Houssam's Movies  Gateway Service")
						)
						.uri("https://www.google.com")
				)
				.route(r -> r.path("/comments/**")
						.filters(f -> f
								.prefixPath("/api")
								.addResponseHeader("X-Powered-By","DanSON Gateway Service")
						)
						.uri("http://localhost:8082")
				)
				.build();
	}

	@Bean
	public RouteLocator UserGatewayBean(){
		return  null;
	}

}


class UserBean extends  RouteLocatorBuilder.Builder {

	public UserBean(ConfigurableApplicationContext context) {
		super(context);
	}

	public RouteLocatorBuilder.Builder routes(RouteLocatorBuilder builder){
		return builder;
	}


}
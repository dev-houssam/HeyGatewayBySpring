package com.api.heyGateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.GatewayFilterSpec;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import reactor.core.publisher.Mono;

import java.util.LinkedList;

@SpringBootApplication
public class GatewayApplication {

	public static void main(String[] args) {
		SpringApplication.run(GatewayApplication.class, args);
	}

	RouteLocatorBuilder builder = null;

	@Bean
	public RouteLocator movieOnlyRootRouteLocator(RouteLocatorBuilder builder) {
		/*

		.prefixPath("/movies")
								.rewritePath("/(?<segment>.*)", "/${segment}/")
								.stripPrefix(1)
								.prefixPath("/")
		* */
		return builder.routes()
				.route(r -> r.path("/api/movies/**")
						.filters(f -> f
								.rewritePath("/api/?(?<segment>.*)/", "/${segment}")
								//.rewritePath("/movies/(?<segment>.*)", "/${segment})
								.prefixPath("/")

							.addResponseHeader("X-Powered-By","Houssam's Movies  Gateway Service")
								.addResponseHeader("Host-Institution","University of Western Brittany's API  Gateway Service")
						)
						.uri("http://localhost:9001")
				)
				.build();

	}

	@Bean
	public RouteLocator movieRouteLocator(RouteLocatorBuilder builder) {
		/*

		.prefixPath("/movies")
								.rewritePath("/(?<segment>.*)", "/${segment}/")
								.stripPrefix(1)
								.prefixPath("/")
		* */
		return builder.routes()
				.route(r -> r.path("/api/movies/**")
						.filters(f -> f
								.prefixPath("/")
								.addResponseHeader("X-Powered-By","Houssam's Movies  Gateway Service")
								.addResponseHeader("Host-Institution","University of Western Brittany's API  Gateway Service")
						)
						.uri("http://localhost:9001")
				)
				.route(r -> r.host("http://localhost:9000/api/movies/")
						.uri("http://localhost:9001/movies")
				)
				.build();

	}

	/*@GetMapping("/api/movies/")
	@Bean
	public Mono<String> movieOnlyRouteLocator(RouteLocatorBuilder builder){
		return Mono.just("Error : faites '/api/movies' à la place");
	}*/

	@GetMapping("/test")
	public Mono<String> movieOnlyRouteLocator(RouteLocatorBuilder builder){
		return Mono.just("Execution /test");
	}

}

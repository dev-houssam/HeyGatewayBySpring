package com.api.heyGateway.util;

import lombok.Value;
//import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class JwtUtil {
    //@Value("${jwt.secret}")
    private String secret;

    /*public String extractUsername(String token) {
        //return extractClaim(token, Claims::getSubject);
        return "token_generated_nonononno";
    }
    public List<String> extractRoles(String token) {
        Claims claims = extractAllClaims(token);
        return claims.get("roles", List.class);
        return List.copyOf(null);
    }

    private Claims extractAllClaims(String token) {
        return new Claims();
    }

    public Boolean isTokenValid(String token) {
        return false;
    }
    public String generateToken(UserDetails userDetails) {
        return "my_token";
    }*/
}


package com.api.heyGateway.controller;

//package org.example.gatewayauth.controller;

/*
import org.example.gatewayauth.model.AuthenticationRequest;
import org.example.gatewayauth.model.AuthenticationResponse;
import org.example.gatewayauth.model.User;
import org.example.gatewayauth.service.JwtService;
import org.example.gatewayauth.service.UserService;

 */
import com.api.heyGateway.models.AuthenticationRequest;
import com.api.heyGateway.models.AuthenticationResponse;
import com.api.heyGateway.models.User;
import com.api.heyGateway.service.JwtService;
import com.api.heyGateway.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/auth")
public class AuthController {
    @Autowired private JwtService jwtService;
    @Autowired private UserService userService;

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody AuthenticationRequest request) throws Exception {
        String jwt = jwtService.createJwtToken(request);
        return ResponseEntity.ok(new AuthenticationResponse(jwt));
    }

    @PostMapping("/signup")
    public ResponseEntity<?> signup(@RequestBody User user) {
        if (userService.findByUsername(user.getUsername()) != null) {
            return ResponseEntity.badRequest().body("Username is already taken.");
        }
        userService.save(user);
        return ResponseEntity.ok("User registered successfully.");
    }
}
